package never_use_switch;

/**
 * Created by Evegeny on 21/04/2017.
 */
public interface MailGenerator {
    String generateHtml();
}
