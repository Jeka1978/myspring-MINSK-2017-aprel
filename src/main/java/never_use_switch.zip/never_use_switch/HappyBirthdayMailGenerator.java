
package never_use_switch;

import org.springframework.stereotype.Component;

/**
 * Created by Evegeny on 21/04/2017.
 */
@Component("1")
public class HappyBirthdayMailGenerator implements MailGenerator {
    @Override
    public String generateHtml() {
        //50 lines of business code for building mail
        return "happy birthday, сестра!";
    }

}
